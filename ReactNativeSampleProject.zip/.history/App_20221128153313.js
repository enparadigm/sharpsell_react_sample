import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { Button, StyleSheet, Text, View } from 'react-native';
import { NativeModules } from 'react-native';
import messaging from '@react-native-firebase/messaging';

const { SharpSellSDK } = NativeModules;
export default function App() {
  return (
    <View style={styles.container}>
      <Text>Hello There!</Text>
      <Text></Text>
      <Text>This is Demo Sharpsell SDK Project!</Text>
      <Text></Text>
      <Button title='Open Home Page' onPress={onPress}></Button>
      <StatusBar style="auto" />
    </View>
  );
}
const onPress = async () => {
  const fcmToken = await messaging().getToken();
 if (fcmToken) {
    console.log(fcmToken);
 } 
  SharpSellSDK.getHomeScreen('{"userId":"9999999999","user_group_id":"1","contactNumberPrimary":"9999999999","firstName":"soham test","fcm_token":'+fcmToken+'}')
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

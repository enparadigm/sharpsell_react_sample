package com.myreactnative;


import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

import android.annotation.SuppressLint;
import android.util.Log;
import android.widget.Toast;
import com.enparadigm.sharpsell.sdk.ErrorListener;
import com.enparadigm.sharpsell.sdk.Sharpsell;
import com.enparadigm.sharpsell.sdk.SuccessListener;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

public class SharpSellSDK extends ReactContextBaseJavaModule {
    
    //constructor
    public SharpSellSDK(ReactApplicationContext reactContext) {
        super(reactContext);
    }
    //Mandatory function getName that specifies the module name
    @Override
    public String getName() {
        return "SharpSellSDK";
    };

    public String getData(String obj){
    try{
        JSONObject objData = new JSONObject(obj);
        JSONObject data = new JSONObject();
        data.put("company_code", "idfc-collections");
        data.put("user_unique_id", objData.getString("userId"));
        data.put("user_group_id", 1);
        data.put("country_code", null); 
        data.put("name", objData.getString("firstName"));
        data.put("mobile_number", objData.getString("contactNumberPrimary"));
        // Temporarly commented
        //data.put("email", objData.getString("emailAddress"));

        return data.toString();
    } catch(Exception e){
        e.printStackTrace();
    };
    return "";
    };

    //Custom function that we are going to export to JS
    // Home Screen
    @ReactMethod
    public void getHomeScreen(String data) {
         try{
            Sharpsell.INSTANCE.initialize(
            String objData = getData(data);
            Sharpsell.INSTANCE.initialize(
                getReactApplicationContext(),
                objData,
                new SuccessListener() {
                    @Override
                    public void onSuccess() {
                        Sharpsell.INSTANCE.open(getReactApplicationContext(), null);
                    }
                },
                new ErrorListener<String>() {
                    @Override
                    public void onError(@Nullable String error) {
                    }
                }
            );
         } catch (Exception e){
         }
        
    };

    // Presentation Screen
    @ReactMethod
    public void getPresentationScreen(String data) {
        try{
            String objData = getData(data);
            Sharpsell.INSTANCE.initialize(
                getReactApplicationContext(),
                objData,
                new SuccessListener() {
                    @SuppressLint("LongLogTag")
                    @Override
                    public void onSuccess() {
                        try{
                            JSONObject dataPS = new JSONObject();
                            dataPS.put("route", "productPresentationInput");
                            Sharpsell.INSTANCE.open(getReactApplicationContext(), dataPS.toString());
                        } catch (Exception e){
                        }
                    }
                },
                new ErrorListener<String>() {
                    @Override
                    public void onError(@Nullable String error) {
                    }
                }
            );
        } catch (Exception e){
        };

    };

    // Launchpad Screen
    @ReactMethod
    public void getLaunchpadScreen(String data) {
         try{
            String objData = getData(data);
            Sharpsell.INSTANCE.initialize(
                getReactApplicationContext(),
                objData,
                new SuccessListener() {
                    @SuppressLint("LongLogTag")
                    @Override
                    public void onSuccess() {
                        try{
                            JSONObject dataLS = new JSONObject();
                            dataLS.put("route", "launchpad");
                            Sharpsell.INSTANCE.open(getReactApplicationContext(), dataLS.toString());
                        } catch (Exception e){
                        }
                    }
                },
                new ErrorListener<String>() {
                    @Override
                    public void onError(@Nullable String error) {
                    }
                }
            );
        } catch (Exception e){
        }

    }

    @ReactMethod
    public void clearSharpSellSdkData() {
         Sharpsell.INSTANCE.clearData(getReactApplicationContext());
    }

}
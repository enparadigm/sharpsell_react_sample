import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { Button, StyleSheet, Text, View } from 'react-native';
import { NativeModules } from 'react-native';
const { SharpSellSDK } = NativeModules;
export default function App() {
  return (
    <View style={styles.container}>
      <Text>Hello There!</Text>
      <Text></Text>
      <Text>This is Demo Sharpsell SDK Project!</Text>
      <Text></Text>
      <Button title='Open Home Page' onPress={onPress}></Button>
      <StatusBar style="auto" />
    </View>
  );
}
const onPress = () => {
  SharpSellSDK.getHomeScreen('{"user_unique_id":"9999999999","user_group_id":"1","mobile_number":"}')
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
